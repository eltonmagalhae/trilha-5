// ----------------------------------------------------------------------
// TIPAGEM
// ----------------------------------------------------------------------

/**
 * Interface que define o contrato da classe FavoriteManager.
 */
interface IFavoriteManager {
    addFavorite(item: string): void;
    getFavorites(): string[];
}

// ----------------------------------------------------------------------
// CLASSE ABSTRATA
// ----------------------------------------------------------------------

/**
 * Classe Abstrata base para gerenciadores de favoritos.
 * Implementa a lógica central de verificação de duplicatas.
 */
abstract class FavoriteManager implements IFavoriteManager {
    // Array protegido para armazenar a lista de favoritos
    protected favorites: string[] = [];

    /**
     * Verifica se um item já existe na lista.
     * @param item O item a ser verificado.
     * @returns True se o item já existe, False caso contrário.
     */
    protected isDuplicate(item: string): boolean {
        // Normaliza e verifica se a descrição já está no array
        const normalizedItem = item.trim().toLowerCase();
        return this.favorites.some(fav => fav.trim().toLowerCase() === normalizedItem);
    }

    // Métodos abstratos que devem ser implementados nas subclasses
    public abstract addFavorite(item: string): void;
    public abstract getFavorites(): string[];
}

// ----------------------------------------------------------------------
// SUBCLASSE 1: GERENCIADOR DE FILMES (ORDENADO E SEM DUPLICATAS)
// ----------------------------------------------------------------------

/**
 * Gerenciador de Filmes Favoritos.
 * Características: Sem duplicatas e retorna a lista ordenada alfabeticamente.
 */
class MoviesFavoriteManager extends FavoriteManager {

    constructor() {
        super();
        console.log("\nMoviesFavoriteManager criado. (Ordena e evita duplicatas)");
    }

    /**
     * Adiciona o filme e, se não for duplicado, ordena a lista.
     */
    public addFavorite(item: string): void {
        if (!item.trim()) return; // Ignora itens vazios

        if (this.isDuplicate(item)) {
            console.warn(`[AVISO - Filmes] "${item}" já está na lista.`);
            return;
        }

        // Adiciona o novo item
        this.favorites.push(item);
        console.log(`[OK - Filmes] Adicionado: "${item}"`);
    }

    /**
     * Retorna a lista de filmes favoritos em ordem alfabética.
     */
    public getFavorites(): string[] {
        // Retorna uma cópia do array ordenado sem modificar o original (boa prática)
        return [...this.favorites].sort();
    }
}

// ----------------------------------------------------------------------
// SUBCLASSE 2: GERENCIADOR DE LIVROS (ADICIONA NO INÍCIO)
// ----------------------------------------------------------------------

/**
 * Gerenciador de Livros Favoritos.
 * Características: Adiciona novos itens sempre no início da lista.
 */
class BooksFavoriteManager extends FavoriteManager {

    constructor() {
        super();
        console.log("\nBooksFavoriteManager criado. (Adiciona sempre no início)");
    }

    /**
     * Adiciona o livro usando 'unshift' para colocá-lo no início.
     */
    public addFavorite(item: string): void {
        if (!item.trim()) return;

        // Se fosse necessário evitar duplicatas, a lógica 'isDuplicate' seria usada aqui.
        // Como o requisito não especifica evitar duplicatas para Livros, apenas o comportamento de inserção é mantido.
        
        // Adiciona o novo item no INÍCIO do array
        this.favorites.unshift(item);
        console.log(`[OK - Livros] Adicionado no início: "${item}"`);
    }

    /**
     * Retorna a lista de livros favoritos como está (ordem de inserção).
     */
    public getFavorites(): string[] {
        return [...this.favorites];
    }
}

// ----------------------------------------------------------------------
// EXEMPLO DE USO
// ----------------------------------------------------------------------

const filmes = new MoviesFavoriteManager();
filmes.addFavorite("Pulp Fiction");
filmes.addFavorite("O Poderoso Chefão");
filmes.addFavorite("Matrix");
filmes.addFavorite("O Poderoso Chefão"); // Tenta duplicar

const livros = new BooksFavoriteManager();
livros.addFavorite("1984");
livros.addFavorite("Dom Casmurro");
livros.addFavorite("Duna"); // Será o primeiro da lista

console.log("\n--- LISTA DE FILMES FAVORITOS (Ordenada) ---");
filmes.getFavorites().forEach(f => console.log(`- ${f}`));

console.log("\n--- LISTA DE LIVROS FAVORITOS (Invertida) ---");
livros.getFavorites().forEach(l => console.log(`- ${l}`));