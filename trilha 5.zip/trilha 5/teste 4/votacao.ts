// ----------------------------------------------------------------------
// TIPAGEM
// ----------------------------------------------------------------------

/**
 * Define o tipo de objeto para armazenar os votos: Candidato (string) e Votos (number).
 */
type VoteTally = Record<string, number>;

/**
 * Define o tipo para os resultados ordenados de uma enquete (Poll).
 */
interface PollResult {
    candidato: string;
    votos: number;
}

// ----------------------------------------------------------------------
// CLASSE ABSTRATA
// ----------------------------------------------------------------------

/**
 * Classe Abstrata base para sistemas de votação.
 */
abstract class VoteSystem {
    // Armazena os votos de forma genérica (protected para acesso em subclasses)
    protected votes: VoteTally = {};

    /**
     * Incrementa o voto para um candidato.
     * @param candidate O nome do candidato.
     */
    protected registerVote(candidate: string): void {
        if (!candidate || candidate.trim() === "") {
            console.warn("AVISO: Nome do candidato não pode ser vazio.");
            return;
        }
        
        // Inicializa em 0 se for o primeiro voto, senão incrementa
        this.votes[candidate] = (this.votes[candidate] || 0) + 1;
        console.log(`[OK] Voto registrado para: ${candidate}`);
    }

    // Métodos abstratos que devem ser implementados nas subclasses
    public abstract voteFor(candidate: string): void;
    public abstract getResults(): object;
}

// ----------------------------------------------------------------------
// SUBCLASSE 1: ELEIÇÃO (SOMA TOTAL)
// ----------------------------------------------------------------------

/**
 * Sistema de Eleição. Retorna o total de votos por candidato em um objeto.
 */
class Election extends VoteSystem {
    constructor() {
        super();
        console.log("\nElection: Sistema de Eleição criado.");
    }

    public voteFor(candidate: string): void {
        this.registerVote(candidate);
    }

    /**
     * Retorna um objeto com a contagem total de votos.
     * @returns O objeto VoteTally (Record<string, number>).
     */
    public getResults(): VoteTally {
        // Retorna uma cópia do objeto de votos
        return { ...this.votes };
    }
}

// ----------------------------------------------------------------------
// SUBCLASSE 2: ENQUETE (ORDENADO)
// ----------------------------------------------------------------------

/**
 * Sistema de Enquete (Poll). Retorna uma lista ordenada por votos.
 */
class Poll extends VoteSystem {
    constructor() {
        super();
        console.log("\nPoll: Sistema de Enquete criado.");
    }

    public voteFor(candidate: string): void {
        this.registerVote(candidate);
    }

    /**
     * Retorna uma lista de objetos, ordenados por votos (do maior para o menor).
     * @returns Array de PollResult.
     */
    public getResults(): PollResult[] {
        // 1. Converte o objeto de votos para um array de pares [candidato, votos]
        const resultsArray = Object.entries(this.votes).map(([candidato, votos]) => ({
            candidato,
            votos
        }));

        // 2. Ordena o array pela quantidade de votos (ordem decrescente)
        resultsArray.sort((a, b) => b.votos - a.votos);

        return resultsArray;
    }
}

// ----------------------------------------------------------------------
// EXEMPLO DE USO
// ----------------------------------------------------------------------

// 1. Eleição: Votação para Presidente
const eleicao = new Election();
eleicao.voteFor("Candidato A");
eleicao.voteFor("Candidato B");
eleicao.voteFor("Candidato A");
eleicao.voteFor("Candidato C");
eleicao.voteFor("Candidato B");
eleicao.voteFor("Candidato A");

// 2. Enquete: Votação para Melhor Opção
const enquete = new Poll();
enquete.voteFor("Opção X");
enquete.voteFor("Opção Y");
enquete.voteFor("Opção X");
enquete.voteFor("Opção Z");
enquete.voteFor("Opção Y");

console.log("\n--- RESULTADOS DA ELEIÇÃO (Objeto de Totais) ---");
console.log(eleicao.getResults());

console.log("\n--- RESULTADOS DA ENQUETE (Lista Ordenada) ---");
const resultadosEnquete = enquete.getResults() as PollResult[];
resultadosEnquete.forEach((r, index) => {
    console.log(`${index + 1}º Lugar: ${r.candidato} (${r.votos} votos)`);
});