// ----------------------------------------------------------------------
// TIPAGEM
// ----------------------------------------------------------------------

/**
 * Define o tipo de objeto que o inventário deve retornar:
 * Chaves (string) para os nomes dos itens e Valores (number) para as quantidades.
 */
type InventoryRecord = Record<string, number>;

// ----------------------------------------------------------------------
// CLASSE ABSTRATA
// ----------------------------------------------------------------------

/**
 * Classe Abstrata base para todos os tipos de inventário.
 * Implementa a lógica central de remoção e listagem.
 */
abstract class Inventory {
    // Atributo protegido para armazenar o inventário (Item: Quantidade)
    protected items: InventoryRecord = {};

    /**
     * Método abstrato para adicionar itens. Deve ser implementado nas subclasses
     * para aplicar regras específicas (como limites).
     */
    public abstract addItem(item: string, quantity: number): void;

    /**
     * Remove um item completamente do inventário.
     * @param item O nome do item a ser removido.
     */
    public removeItem(item: string): void {
        if (this.items[item] !== undefined) {
            delete this.items[item];
            console.log(`[OK] Item "${item}" removido do inventário.`);
        } else {
            console.warn(`[AVISO] Item "${item}" não encontrado para remoção.`);
        }
    }

    /**
     * Retorna o inventário completo (Item: Quantidade).
     * @returns Um objeto Record<string, number> do inventário.
     */
    public getInventory(): InventoryRecord {
        return { ...this.items }; // Retorna uma cópia para evitar modificação externa
    }
}

// ----------------------------------------------------------------------
// SUBCLASSE 1: INVENTÁRIO DE ARMAZÉM (GRANDE CAPACIDADE)
// ----------------------------------------------------------------------

/**
 * Inventário de Armazém. Não possui limite de quantidade por item.
 */
class WarehouseInventory extends Inventory {
    constructor() {
        super();
        console.log("\nWarehouseInventory: Inventário de Armazém criado (Sem limite).");
    }

    /**
     * Adiciona itens de forma genérica, permitindo grandes quantidades.
     */
    public addItem(item: string, quantity: number): void {
        if (quantity <= 0) {
            console.error(`ERRO: Quantidade deve ser positiva para adicionar.`);
            return;
        }
        
        // Adiciona a quantidade ao total existente (ou inicializa se for novo)
        this.items[item] = (this.items[item] || 0) + quantity;
        console.log(`[Warehouse OK] Adicionado ${quantity} de ${item}. Total: ${this.items[item]}`);
    }
}

// ----------------------------------------------------------------------
// SUBCLASSE 2: INVENTÁRIO DE LOJA (LIMITE POR ITEM)
// ----------------------------------------------------------------------

/**
 * Inventário de Loja. Possui um limite de 10 unidades por item.
 */
class StoreInventory extends Inventory {
    private readonly MAX_QUANTITY_PER_ITEM = 10;

    constructor() {
        super();
        console.log("\nStoreInventory: Inventário de Loja criado (Máximo 10 por item).");
    }

    /**
     * Adiciona itens, verificando e aplicando o limite máximo.
     */
    public addItem(item: string, quantity: number): void {
        if (quantity <= 0) {
            console.error(`ERRO: Quantidade deve ser positiva para adicionar.`);
            return;
        }

        const currentQuantity = this.items[item] || 0;
        const newTotal = currentQuantity + quantity;

        if (newTotal > this.MAX_QUANTITY_PER_ITEM) {
            const excess = newTotal - this.MAX_QUANTITY_PER_ITEM;
            const toAdd = quantity - excess;

            if (toAdd > 0) {
                 this.items[item] = this.MAX_QUANTITY_PER_ITEM;
                 console.warn(`[Store AVISO] Limite atingido. Adicionado apenas ${toAdd} de ${item}. ${excess} rejeitado.`);
            } else {
                 console.warn(`[Store AVISO] Item "${item}" já está cheio. Nada adicionado.`);
            }
        } else {
            this.items[item] = newTotal;
            console.log(`[Store OK] Adicionado ${quantity} de ${item}. Total: ${newTotal}`);
        }
    }
}

// ----------------------------------------------------------------------
// EXEMPLO DE USO
// ----------------------------------------------------------------------

// 1. Instanciar inventários
const armazem = new WarehouseInventory();
armazem.addItem("Parafuso A", 500);
armazem.addItem("Caixa B", 120);

// 2. Testar limites da Loja
const loja = new StoreInventory();
loja.addItem("Vela Aroma", 5);
loja.addItem("Vela Aroma", 3); // Total: 8 (OK)
loja.addItem("Vela Aroma", 5); // Tenta 5, só cabe 2. Total: 10 (LIMITE)
loja.addItem("Caderno", 10); // Total: 10 (LIMITE)

// 3. Listar inventários
console.log("\n--- INVENTÁRIO DO ARMAZÉM ---");
console.log(armazem.getInventory());

console.log("\n--- INVENTÁRIO DA LOJA ---");
console.log(loja.getInventory());

// 4. Testar Remoção
armazem.removeItem("Caixa B");
armazem.removeItem("Item Inexistente");
console.log("\n--- INVENTÁRIO FINAL DO ARMAZÉM ---");
console.log(armazem.getInventory());