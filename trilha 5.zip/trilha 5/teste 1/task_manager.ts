// ----------------------------------------------------------------------
// TIPAGEM (Interfaces e Tipos)
// ----------------------------------------------------------------------

/**
 * Interface base para os tipos de tarefa (Projeto ou Diária).
 */
interface Task {
    id: number;
    description: string;
    type: 'Project' | 'Daily';
}

/**
 * Interface que define o contrato da classe TaskManager.
 */
interface ITaskManager {
    addTask(task: string): void;
    listTasks(): string[];
}

// ----------------------------------------------------------------------
// CLASSE ABSTRATA
// ----------------------------------------------------------------------

/**
 * Classe Abstrata base para gerenciamento de tarefas.
 * Implementa a lógica central de armazenamento e verificação de duplicatas.
 */
abstract class TaskManager implements ITaskManager {
    // Array que armazena todos os objetos Task
    protected tasks: Task[] = [];
    private nextId: number = 1;

    /**
     * Verifica se uma descrição de tarefa já existe no array.
     * @param description A descrição da tarefa a ser verificada.
     * @returns True se a tarefa já existe, False caso contrário.
     */
    protected isDuplicate(description: string): boolean {
        // Normaliza a descrição para ignorar case e espaços extras na checagem
        const normalizedDescription = description.trim().toLowerCase();
        return this.tasks.some(task => task.description.trim().toLowerCase() === normalizedDescription);
    }

    /**
     * Adiciona uma tarefa ao array, garantindo que não seja duplicada.
     * @param description A descrição da tarefa.
     * @param type O tipo da tarefa ('Project' ou 'Daily').
     */
    protected registerTask(description: string, type: 'Project' | 'Daily'): void {
        if (!description.trim()) {
            console.error(`ERRO: A tarefa não pode ser vazia.`);
            return;
        }

        if (this.isDuplicate(description)) {
            console.warn(`AVISO: Tarefa duplicada não adicionada: "${description}"`);
            return;
        }

        const newTask: Task = {
            id: this.nextId++,
            description: description,
            type: type
        };

        this.tasks.push(newTask);
        console.log(`[OK] Tarefa (${type}) adicionada: "${description}"`);
    }

    // Métodos abstratos que devem ser implementados nas subclasses
    public abstract addTask(task: string): void;
    public abstract listTasks(): string[];
}

// ----------------------------------------------------------------------
// SUBCLASSES CONCRETAS
// ----------------------------------------------------------------------

/**
 * Subclasse para gerenciamento de tarefas específicas de um Projeto.
 */
class Project extends TaskManager {
    public projectName: string;

    constructor(projectName: string) {
        super();
        this.projectName = projectName;
    }

    public addTask(task: string): void {
        this.registerTask(task, 'Project');
    }

    /**
     * Retorna a lista de tarefas do projeto, formatada.
     */
    public listTasks(): string[] {
        return this.tasks.map(task => `[PROJETO ${this.projectName} - ID ${task.id}] ${task.description}`);
    }
}

/**
 * Subclasse para gerenciamento de Tarefas Diárias.
 */
class DailyTasks extends TaskManager {
    public addTask(task: string): void {
        this.registerTask(task, 'Daily');
    }

    /**
     * Retorna a lista de tarefas diárias, formatada.
     */
    public listTasks(): string[] {
        return this.tasks.map(task => `[DIÁRIA - ID ${task.id}] ${task.description}`);
    }
}

// ----------------------------------------------------------------------
// EXEMPLO DE USO E TESTE DE DUPLICATAS
// ----------------------------------------------------------------------

const projetoApi = new Project("API Backend");
const tarefasDiarias = new DailyTasks();

console.log("\n--- ADICIONANDO TAREFAS DE PROJETO ---");
projetoApi.addTask("Definir endpoints de autenticação");
projetoApi.addTask("Implementar cache de banco de dados");
projetoApi.addTask("Definir endpoints de autenticação"); // Duplicata

console.log("\n--- ADICIONANDO TAREFAS DIÁRIAS ---");
tarefasDiarias.addTask("Responder e-mails");
tarefasDiarias.addTask("Revisar código do colega");
tarefasDiarias.addTask("Responder e-mails"); // Duplicata

console.log("\n--- LISTA DE TAREFAS DO PROJETO ---");
projetoApi.listTasks().forEach(t => console.log(t));

console.log("\n--- LISTA DE TAREFAS DIÁRIAS ---");
tarefasDiarias.listTasks().forEach(t => console.log(t));